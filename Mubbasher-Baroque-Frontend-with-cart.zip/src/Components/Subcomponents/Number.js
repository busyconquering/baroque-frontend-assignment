export const Number = (value) =>
  new Intl.NumberFormat('en-IN').format(value);