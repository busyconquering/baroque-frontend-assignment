export const MainpageproductsApis = [

    {
        ProductId: 0,
        ProductTitle : "UNSTITCHED",
        Productsrc : "https://cdn.shopify.com/s/files/1/2277/5269/files/677_550x.jpg?v=1666853257"
    },

    {
        ProductId: 1,
        ProductTitle : "DUPATTAS",
        Productsrc : "https://cdn.shopify.com/s/files/1/2277/5269/files/g_88d33f5c-80c4-4c8d-9ae3-53c3aeaf34dd_550x.jpg?v=1666854733"
    },

    {
        ProductId: 2,
        ProductTitle : "READY TO WEAR",
        Productsrc : "https://cdn.shopify.com/s/files/1/2277/5269/files/11_20332457-55a4-41e8-8164-b26fc5d8d277_550x.jpg?v=1666853475"
    },

    {
        ProductId: 3,
        ProductTitle : "SPECIAL PRICES",
        Productsrc : "https://cdn.shopify.com/s/files/1/2277/5269/files/fg_508cff4d-40ab-4743-b28b-cfebf13cc9ab_550x.jpg?v=1654861435"
    },

    {
        ProductId: 4,
        ProductTitle : "BOTTOMS",
        Productsrc : "https://cdn.shopify.com/s/files/1/2277/5269/files/banner_bc20ba87-12c8-4d94-9e8c-007f885dcc3d_550x.jpg?v=1639996999"
    },

    {
        ProductId: 5,
        ProductTitle : "VELVET SHAWL",
        Productsrc : "https://cdn.shopify.com/s/files/1/2277/5269/files/FF_6ad30586-40fc-4210-8a9d-5137f2ad3554_550x.jpg?v=1666853812"
    },

]