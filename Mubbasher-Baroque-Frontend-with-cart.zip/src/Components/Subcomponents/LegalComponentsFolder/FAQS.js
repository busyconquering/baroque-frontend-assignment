import React from 'react'

export default function FAQS() {
  return (
    <div>
      FAQ'S
    </div>
  )
}
