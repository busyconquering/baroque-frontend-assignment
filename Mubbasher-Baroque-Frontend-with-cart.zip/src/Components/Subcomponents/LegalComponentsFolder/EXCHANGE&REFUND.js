import React from 'react'

export default function EXCHANGEREFUND() {
  return (
    <div className='mt-2'>
        <p className='pt-24 pb-72'>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit necessitatibus optio enim inventore ipsa beatae labore. Blanditiis, et iusto atque id impedit quia corrupti rem molestiae facilis consequuntur provident ipsa quibusdam, qui cumque exercitationem repudiandae reprehenderit debitis inventore nostrum ab aperiam eligendi vero aliquam. Provident aut vel ab nostrum minima, commodi repellat, minus dolor eius sequi maiores quod necessitatibus vero saepe ullam consequuntur quaerat illo culpa ex dignissimos! Unde adipisci laudantium tempore ipsa. Porro at repudiandae inventore, quia eos aut sit, voluptas quaerat placeat soluta eaque similique reiciendis veritatis vel a, consectetur non. Ratione repellat optio hic voluptatem tempora, perspiciatis nihil odio error.
        </p>
    </div>
  )
}
