import React from 'react'

export default function LEGAL() {
  return (
    <div>
      LEGAL
    </div>
  )
}
