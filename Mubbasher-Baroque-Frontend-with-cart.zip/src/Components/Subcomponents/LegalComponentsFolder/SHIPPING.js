import React from 'react'

export default function SHIPPING() {
  return (
    <div>
      SHIPPING
    </div>
  )
}
