import React from 'react'

export default function CAREERS() {
  return (
    <div>
      CAREERS
    </div>
  )
}
